package com.shan.springmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMailApplicationTests {

    @Test
    void contextLoads() {
    }

}
